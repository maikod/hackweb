/*
 *	Made by Frenki
 *	hackweb.altervista.org
 *	frank10gm@gmail.com
 */

#include <stdio.h>
#include <sys/io.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pci/pci.h>

#define REGISTER_OFFSET           0x00061254

static unsigned int GMA950_BACKLIGHT_MAX;

char* memory;

static inline unsigned int readl(const volatile void *addr)
{
	return *(volatile unsigned int*) addr;
}

static inline void writel(unsigned int b, volatile void *addr)
{
	*(volatile unsigned int*) addr = b;
}

#define INREG(addr)		readl(memory+addr)
#define OUTREG(addr,val)	writel(val, memory+addr)

static unsigned int
gma950_backlight_get_max(void)
{
  return (INREG(REGISTER_OFFSET) >> 17);
}


unsigned int read_backlight() 
{
  return (INREG(REGISTER_OFFSET) >> 1) & 0x7fff;
}

void write_backlight_value(unsigned int value) {
  OUTREG(REGISTER_OFFSET, (GMA950_BACKLIGHT_MAX << 17) | (value << 1));
}

void write_backlight(unsigned char value) {
	unsigned int current = read_backlight();

	if (current < value) {
		while (current < value) {
			current += 5;
			if (current > value)
				current = value;
			write_backlight_value((unsigned char)current);
			usleep(50000);
		}
	}
	else {
		while (current > value) {
			current -= 5;
			if (current < value)
				current = value;
			write_backlight_value((unsigned char)current);
			usleep(50000);
		}
	}
}






void usage(char* argv0) {
	printf("Apple Macbook (pro) backlight control " VERSION);
	printf("\n");
	printf("Usage:\n");
	printf("%s: read current value\n", argv0);
	printf("%s value: write value [0-255]\n", argv0);
	printf("%s +n: increase value by n\n", argv0);
	printf("%s -n: decrease value by n\n", argv0);
}

int main(int argc, char** argv) {
	if (argc > 2) {
		usage(argv[0]);
		return 1;
	}

	char* endptr;
	int ret = 0;
	long address = 0;
	long length = 0;
	int fd;
	int state;

	/* Search for the graphics card. */
	/* Default values: */
	/* address = 0x90300000; */
	/* length = 0x20000; */

	struct pci_access *pacc = pci_alloc();
	pci_init(pacc);
	pci_scan_bus(pacc);
	struct pci_dev *dev;
	for(dev=pacc->devices; dev; dev=dev->next) {	/* Iterate over all devices */
		pci_fill_info(dev, PCI_FILL_IDENT | PCI_FILL_BASES);
		if ((dev->vendor_id == 0x8086) && (dev->device_id == 0x27A2)) { // ATI X1600
			address = dev->base_addr[0];
			length = dev->size[0];
		}
	}
	pci_cleanup(pacc);

	if (!address) {
		printf("Failed to detect video card, aborting...\n");
		return 1;
	}



	fd = open("/dev/mem", O_RDWR);
	
	if (fd < 0) {
		perror("cannot open /dev/mem");
		return 1;
	}

	memory = mmap(NULL, length, PROT_READ|PROT_WRITE, MAP_SHARED, fd, address);

	if (memory == MAP_FAILED) {
		perror("mmap failed");
		return 1;
	}

	/* Is it really necessary ? */
	OUTREG(0x4dc, 0x00000005);
	state = INREG(0x7ae4);
	OUTREG(0x7ae4, state);


int gma950_backlight_map(void)
{
  if ((address == 0) || (length == 0))
    {
      
      return 1;
    }

  fd = open("/dev/mem", O_RDWR);
	
  if (fd < 0)
    {
     
      return 1;
    }

  memory = mmap(NULL, length, PROT_READ|PROT_WRITE, MAP_SHARED, fd, address);

  if (memory == MAP_FAILED)
    {
      
      return 1;
    }

  return 0;
}






  /* Get the maximum backlight value */
  ret = gma950_backlight_map();
  if (ret < 0)
    {
      
      return 1;
    }

  GMA950_BACKLIGHT_MAX = gma950_backlight_get_max();

	if (argc == 2) {
		if (argv[1][0] == '+') {
			long value = strtol(&argv[1][1], &endptr, 10);
			if ((value < 0) || (value > 148) || (endptr[0])) {
				printf("Invalid value \"%s\" (should be an integer between 0 and 255).\n", &argv[1][1]);
				usage(argv[0]);
				ret = 1;
			}
			else {
				value = read_backlight()+value;
				if (value > 148)
					value = 148;
				write_backlight(value);
			}
		}
		else if (argv[1][0] == '-') {
			long value = strtol(&argv[1][1], &endptr, 10);
			if ((value < 0) || (value > 148) || (endptr[0])) {
				printf("Invalid value \"%s\" (should be an integer between 0 and 255).\n", &argv[1][1]);
				usage(argv[0]);
				ret = 1;
			}
			else {
				value = read_backlight()-value;
				if (value < 18)
					value = 18;
				write_backlight(value);
			}
		}
		else {
			long value = strtol(argv[1], &endptr, 10);
			if ((value < 0) || (value > 148) || (endptr[0])) {
				printf("Invalid value \"%s\" (should be an integer between 0 and 255).\n", argv[1]);
				usage(argv[0]);
				ret = 1;
			}
			else {
				write_backlight(value);
			}
		}
	}
	else {
		printf("%d\n", read_backlight());
	}

	munmap(memory, length);
	close(fd);

	return ret;
}
